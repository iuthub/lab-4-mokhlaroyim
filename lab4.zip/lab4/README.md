# Lab 4: Buy Grades For Money

In this exercises, you should make a form which takes payment information from suckers who want to buy a grade, and store it in a `suckers.txt` file.


### Student Details:

- **Student ID**: U1610120
- **Student Name**: Anora Kosimova
- **Section Number**: 002 section number
